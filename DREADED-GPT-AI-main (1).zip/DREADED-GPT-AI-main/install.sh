npm install

npm i -g forever && forever index.js && forever save && forever logs
